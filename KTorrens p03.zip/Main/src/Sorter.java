//**************************************************************************************************
// CLASS: Sorter
// AUTHOR
// Kevin Torrens(ktorrens@asu.edu)
// Computer Science & Engineering Program
// Fulton Schools of Engineering
// Arizona State University, Tempe, AZ 85287-8809
//****************************************************************************************

import java.util.ArrayList;

import java.util.Collections;

import java.util.Comparator;

public class Sorter {

    //Implementation of sort method

    //sort method to sort the student by last name

    public static ArrayList<Student> sort(ArrayList<Student> mStudentList) {



        Collections.sort(mStudentList, new Comparator<Student>() {

            //used the comparator class to sort the student by their last name

            @Override

            //Implementation of compare function

            public int compare(Student o1, Student o2) {

                return o1.getLastName().compareTo(o2.getLastName());

            }

        });

        return mStudentList;

    }

}