//**************************************************************************************************
// CLASS: View
// AUTHOR
// Kevin Torrens(ktorrens@asu.edu)
// Computer Science & Engineering Program
// Fulton Schools of Engineering
// Arizona State University, Tempe, AZ 85287-8809
//**************************************************************************************************

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * The View class implements the GUI. It is a subclass of JFrame and implements the ActionListener
 * interface so that we can respond to user-initiated GUI events.
 */
public class View extends JFrame implements ActionListener {

/**
 * The width of the View.
 */
public static final int FRAME_WIDTH  = 500;

/**
 * The height of the View.
 */
public static final int FRAME_HEIGHT = 250;

/// Declare instance variables
private JButton mClearButton;
    private JTextField[] mExamText;
    private JButton mExitButton;
    private JTextField[] mHomeworkText;
    private Main mMain;
    private JButton mSaveButton;
    private JButton mSearchButton;
    private JTextField mSearchText;
    private Student mStudent;

    /**
     * View()
     * The View constructor creates the GUI interface and makes the frame visible at the end.
     */
    public View(Main pMain) {

        mMain = pMain;

        JPanel panelSearch = new JPanel(new FlowLayout());
        JLabel studentName = new JLabel("Student Name: ");
        panelSearch.add(studentName);
        mSearchText = new JTextField(25);
        panelSearch.add(mSearchText);
        mSearchButton = new JButton("Search");
        mSearchButton.addActionListener(this);
        panelSearch.add(mSearchButton);

        JPanel panelHomework = new JPanel(new FlowLayout());
        JLabel homework = new JLabel("Homework: ");
        panelHomework.add(homework);
        mHomeworkText = new JTextField[CourseConstants.NUM_HOMEWORKS];
        for (int i = 0; i <CourseConstants.NUM_HOMEWORKS ; i++) {
            mHomeworkText[i] = new JTextField(5);
            panelHomework.add(mHomeworkText[i]);
        }

        JPanel panelExam = new JPanel(new FlowLayout());
        JLabel exam = new JLabel("Exam: ");
        panelExam.add(exam);
        mExamText = new JTextField[CourseConstants.NUM_EXAMS];
        for (int i = 0; i <CourseConstants.NUM_EXAMS ; i++) {
            mExamText[i] = new JTextField(5);
            panelExam.add(mExamText[i]);
        }

        JPanel panelButtons = new JPanel(new FlowLayout());
        mClearButton = new JButton("Clear");
        mClearButton.addActionListener(this);
        panelButtons.add(mClearButton);
        mSaveButton = new JButton("Save");
        mSaveButton.addActionListener(this);
        panelButtons.add(mSaveButton);
        mExitButton = new JButton("Exit");
        mExitButton.addActionListener(this);
        panelButtons.add(mExitButton);

        JPanel panelMain = new JPanel();
        panelMain.setLayout(new BoxLayout(panelMain,BoxLayout.Y_AXIS));
        panelMain.add(panelSearch);
        panelMain.add(panelHomework);
        panelMain.add(panelExam);
        panelMain.add(panelButtons);

        setTitle("Gradebookulator");
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(panelMain);
        setVisible(true);
    }

    /**
     * actionPerformed()
     * Called when one of the JButtons is clicked. Detects which button was clicked and handles it.
     */
    public void actionPerformed(ActionEvent pEvent){

        if (pEvent.getActionCommand().equalsIgnoreCase("Search")){
            String lastName = mSearchText.getText();
            if (lastName.isEmpty()){
                messageBox("Please enter the student's last name.");
            } else {
                mStudent = mMain.search(lastName);
                if (mStudent == null){
                    messageBox("Student not found. Try again.");
                } else {
                    displayStudent(mStudent);
                }
            }
        } else if (pEvent.getActionCommand().equalsIgnoreCase("Save")){
            if (mStudent != null){
                saveStudent(mStudent);
            }
        } else if (pEvent.getActionCommand().equalsIgnoreCase("Clear")){
            clear();
        } else if (pEvent.getActionCommand().equalsIgnoreCase("Exit")){
            if (mStudent != null)
            {
                saveStudent(mStudent);
            }
            mMain.exit();
        }
    }

    /**
     * clear()
     * Called when the Clear button is clicked. Clears all of the text fields by setting the contents to the empty string.
     * After clear() returns, no student information is being edited or displayed.
     */
    private void clear(){
        mSearchText.setText("");
        for (JTextField tf: mHomeworkText){
            tf.setText("");
        }
        for (JTextField tf:mExamText){
            tf.setText("");
        }
        mStudent = null;
    }

    /**
     * displayStudent()
     * Displays the homework and exam scores for a student in the mHomeworkText and mExamText text fields.
     */
    private void displayStudent(Student pStudent){
        for (int i = 0; i <CourseConstants.NUM_HOMEWORKS ; i++) {
            int hw = pStudent.getHomework(i);
            String hwStr = Integer.toString(hw);
            mHomeworkText[i].setText(hwStr);
        }
        for (int i = 0; i <CourseConstants.NUM_EXAMS ; i++) {
            mExamText[i].setText(Integer.toString(pStudent.getExam(i)));
        }
    }

    /**
     * messageBox()
     * Displays a message box containing some text.
     */
    public void messageBox(String pMessage) {
        JOptionPane.showMessageDialog(this, pMessage, "Message", JOptionPane.PLAIN_MESSAGE);
    }

    /**
     * saveStudent()
     * Retrieves the homework and exam scores for pStudent from the text fields and writes the results to the Student record
     * in the Roster.
     */
    private void saveStudent(Student pStudent){

        for (int i = 0; i <CourseConstants.NUM_HOMEWORKS ; i++){
            String hwStr = mHomeworkText[i].getText();
            pStudent.setHomework(i,Integer.parseInt(hwStr));
        }
        for (int i = 0; i <CourseConstants.NUM_EXAMS ; i++){
            String examStr = mExamText[i].getText();
            pStudent.setExam(i,Integer.parseInt(examStr));
        }
    }

}