import java.util.ArrayList;

//Implementation of Searcher class

public class Searcher {

    //Implementation of search function

    //search method to find the stdent by last name

    public static int search(ArrayList<Student> mStudentList, String pLastName) {

        //Iterate the loop

        for (int i = 0; i < mStudentList.size(); i++) {

            if (mStudentList.get(i).getLastName().equals(pLastName)) {

                return i;

            }

        }

        return -1;

    }

}