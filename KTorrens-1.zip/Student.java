//**************************************************************************************************************
// CLASS: Student
//
// DESCRIPTION
// Abstract Student superclass, implements Comparable interface
//
// COURSE AND PROJECT INFO
// CSE205 Object Oriented Programming and Data Structures
// Project Number: 2
//
// AUTHOR:Kevin Torrens, ktorrens, ktorrens@asu.edu
//**************************************************************************************************************
public abstract class Student implements Comparable<Student>{
    private int mCredits;
    private String mFname;
    private String mId;
    private String mLname;
    private double mTuition;

    /**
     * Student constructor
     */
    public Student(String pId, String pFname, String pLname){
        setId(pId);
        setFname(pFname);
        setLname(pLname);
    }

    /**
     * calcTuition abstract method
     */
    public void calcTuition(){
    }

    /**
     * Overridden compareTo method from Comparable interface
     */
    @Override
    public int compareTo(Student pStudent){
        return getId().compareTo(pStudent.getId());
    }

    /**
     * Accessor that returns mCredits
     */
    public int getCredits(){
        return mCredits;
    }

    /**
     * Accessor that returns mFname
     */
    public String getFirstName(){
        return mFname;
    }

    /**
     * Accessor that returns mId
     */
    public String getId(){
        return mId;
    }

    /**
     * Accessor that returns mLname
     */
    public String getLastName(){
        return mLname;
    }

    /**
     * Accessor that returns mTuition
     */
    public double getTuition(){
        return mTuition;
    }

    /**
     * Mutator for setting mCredits
     */
    public void setCredits(int pCredits){
        mCredits = pCredits;
    }

    /**
     * Mutator for setting mFname
     */
    public void setFname(String pFname){
        mFname = pFname;
    }

    /**
     * Mutator for setting mLname
     */
    public void setLname(String pLname){
        mLname = pLname;
    }

    /**
     * Mutator for setting mId
     */
    public void setId(String pId){
        mId = pId;
    }

    /**
     * Mutator for setting mTuition
     */
    public void setTuition(double pTuition){
        mTuition = pTuition;
    }
}
