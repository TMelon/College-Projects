//**************************************************************************************************************
// CLASS: OnCampusStudent
//
// DESCRIPTION
// OnCampusStudent subclass of Student
//
// COURSE AND PROJECT INFO
// CSE205 Object Oriented Programming and Data Structures
// Project Number: 2
//
// AUTHOR:Kevin Torrens, ktorrens, ktorrens@asu.edu
//**************************************************************************************************************
public class OnCampusStudent extends Student{
    private boolean mResident;
    private double mProgramFee;

    public OnCampusStudent(String pId, String pFname, String pLname){
        super(pId, pFname, pLname);
    }

    /**
     * Overridden calcTuition method - calculates tuition of OnCampusStudents from TuitionConstants
     */
    @Override
    public void calcTuition(){
        double t;
        if(getResidency() == true){
            t = TuitionConstants.ONCAMP_RES_BASE;
        }
        else{
            t = TuitionConstants.ONCAMP_NONRES_BASE;
        }
        t = t + getProgramFee();
        if(getCredits() > TuitionConstants.MAX_CREDITS){
            t = t + (getCredits() - TuitionConstants.MAX_CREDITS) * TuitionConstants.ONCAMP_ADD_CREDITS;
        }
        setTuition(t);
        return;
    }

    /**
     * Returns getProgramFee
     */
    public double getProgramFee(){
        return mProgramFee;
    }

    /**
     * Returns residency status
     */
    public boolean getResidency(){
        return mResident;
    }

    /**
     * Mutator for setting residency status
     */
    public void setResidency(boolean pResident){
        mResident = pResident;
    }

    /**
     * Mutator for setting mProgramFee
     */
    public void setProgramFee(double pProgramFee){
        mProgramFee = pProgramFee;
    }
}