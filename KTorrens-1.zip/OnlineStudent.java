//**************************************************************************************************************
// CLASS: OnlineStudent
//
// DESCRIPTION
// OnlineStudent subclass of Student
//
// COURSE AND PROJECT INFO
// CSE205 Object Oriented Programming and Data Structures
// Project Number: 2
//
// AUTHOR:Kevin Torrens, ktorrens, ktorrens@asu.edu
//**************************************************************************************************************
public class OnlineStudent extends Student{
    private boolean mTechFee;

    public OnlineStudent(String pId, String pFname, String pLname){
        super(pId, pFname, pLname);
    }

    /**
     * Overridden calcTuition method - calculates tuition of OnlineStudends based on TuitionConstants
     */
    @Override
    public void calcTuition(){
        double t = getCredits() * TuitionConstants.ONLINE_CREDIT_RATE;
        if(getTechFee() == true){
            t = t + TuitionConstants.ONLINE_TECH_FEE;
        }
        setTuition(t);
        return;
    }

    /**
     * Accessor that returns mTechFee boolean
     */
    public boolean getTechFee(){
        return mTechFee;
    }

    /**
     * Mutator for setting mTechFee boolean
     */
    public void setTechFee(boolean pTechFee){
        mTechFee = pTechFee;
    }
}