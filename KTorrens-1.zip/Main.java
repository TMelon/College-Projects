// DESCRIPTION
// The Main class for Project 2.
//
// COURSE AND PROJECT INFO
// CSE205 Object Oriented Programming and Data Structures
// Project Number: 2
//
// AUTHOR: Kevin Torrens, ktorrens, ktorrens@asu.edu
//**************************************************************************************************************
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    /**
     *  Instantiate a Main object and call run() on the object.
     */
    public static void main(String[] args) throws FileNotFoundException{
        Main mainObject = new Main();
        mainObject.run();
    }

    /**
     * Calculates the tuition for each student.
     */
    private void calcTuition(ArrayList<Student> pStudentList) {
        for(Student student : pStudentList){
            student.calcTuition();
        }
    }

    /**
     * Reads the student information from "p02-students.txt" and returns the list of students as an ArrayList
     * <Student> object.
     */
    private ArrayList<Student> readFile() throws FileNotFoundException {
        ArrayList<Student> studentList = new ArrayList<Student>();

        Scanner in = new Scanner(new File("p02-students.txt"));

        while(in.hasNext() == true)
        {
            String studentType = in.next();
            if((studentType).equals("C"))
            {
                studentList.add(readOnCampusStudent(in));
                //System.out.println(studentType);
            }
            else
            {
                studentList.add(readOnlineStudent(in));
            }
        }
        in.close();
        return studentList;
    }

    /**
     * Reads the information for an on-campus student.
     */
    private OnCampusStudent readOnCampusStudent(Scanner pIn){
        String id = pIn.next();
        String lname = pIn.next();
        String fname = pIn.next();
        OnCampusStudent student = new OnCampusStudent(id, fname, lname);
        String res = pIn.next();
        double fee = pIn.nextDouble();
        int credits = pIn.nextInt();
        if((res).equals("R")){
            student.setResidency(true);
        }
        else{
            student.setResidency(false);
        }
        student.setProgramFee(fee);
        student.setCredits(credits);

        return student;
    }

    /**
     * Reads the information for an online student.
     */
    private OnlineStudent readOnlineStudent(Scanner pIn) {
        String id = pIn.next();
        String lname = pIn.next();
        String fname = pIn.next();
        OnlineStudent student = new OnlineStudent(id, fname, lname);
        String fee = pIn.next();
        int credits = pIn.nextInt();
        if((fee).equals("T"))
            student.setTechFee(true);
        else
        {
            student.setTechFee(false);
        }
        student.setCredits(credits);
        return student;
    }

    /**
     *  Calls other methods to implement the sw requirements.
     */
    private void run() throws FileNotFoundException {
        try
        {
            Scanner in = new Scanner(new File("p02-students.txt"));
        }
        catch (FileNotFoundException pExcept)
        {
            System.out.println("Sorry, could not open 'p02-students.txt' for reading. Stopping");
            System.exit(-1);
        }
        ArrayList<Student> studentList = readFile();
        calcTuition(studentList);
        Sorter.insertionSort(studentList, Sorter.SORT_ASCENDING);
        writeFile(studentList);
    }

    /**
     *  Writes the output file to "p02-tuition.txt" per the software requirements.
     */
    private void writeFile(ArrayList<Student> pStudentList) throws FileNotFoundException {
        PrintWriter out = new PrintWriter(new File("p020-tuition.txt"));
        for(Student student : pStudentList)
        {
            out.print(student.getId() + " " + student.getLastName() + " " + student.getFirstName() + " ");
            out.printf("%.2f%n", student.getTuition());
        }
        out.close();
    }
}
